
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'business1314151617',
  applicationName: 'git-repo-01',
  appUid: 'd6DtFgxv51wRKnVnxT',
  orgUid: 'KCL28pvPzHV89xg6CM',
  deploymentUid: '4c372d09-7fdd-4bcb-a994-c719245785ed',
  serviceName: 'test-git-01',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.15',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'test-git-01-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}